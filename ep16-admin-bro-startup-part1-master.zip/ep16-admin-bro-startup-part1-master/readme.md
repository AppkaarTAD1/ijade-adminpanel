# JSCasts ep16

This is the repo of a project created during the JSCast ep16: https://youtu.be/n0IuXnL_cWs