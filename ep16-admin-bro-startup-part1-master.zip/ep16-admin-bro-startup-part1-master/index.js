const run = require('./src/server');

run();
